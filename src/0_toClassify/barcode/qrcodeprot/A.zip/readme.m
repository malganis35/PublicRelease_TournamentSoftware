% To run the code type "qrcode" on Matlab Command Window.
% A simple and intuitive GUI should appear.
%
%
% In order to obtain the source code for QR Code Recognition System please visit
%  
% http://www.advancedsourcecode.com/qrcode.asp
%  
% Luigi Rosa
% Via Centrale 35
% 67042 Civita Di Bagno
% L'Aquila - ITALY
% mobile +39 3207214179
% email luigi.rosa@tiscali.it
% website http://www.advancedsourcecode.com